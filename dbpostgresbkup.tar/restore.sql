--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.5
-- Dumped by pg_dump version 11.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Approval";
--
-- Name: Approval; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Approval" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_Singapore.1252' LC_CTYPE = 'English_Singapore.1252';


ALTER DATABASE "Approval" OWNER TO postgres;

\connect "Approval"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auto_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.auto_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.auto_updated_at_column() OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: approval; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.approval (
    id text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    service_rule integer NOT NULL,
    comment text,
    status integer NOT NULL,
    deadline timestamp with time zone NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.approval OWNER TO postgres;

--
-- Name: servicerule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.servicerule (
    id integer NOT NULL,
    name text NOT NULL,
    apikey text NOT NULL,
    url text NOT NULL
);


ALTER TABLE public.servicerule OWNER TO postgres;

--
-- Data for Name: approval; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.approval (id, title, description, service_rule, comment, status, deadline, created_at, updated_at) FROM stdin;
\.
COPY public.approval (id, title, description, service_rule, comment, status, deadline, created_at, updated_at) FROM '$$PATH$$/2818.dat';

--
-- Data for Name: servicerule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.servicerule (id, name, apikey, url) FROM stdin;
\.
COPY public.servicerule (id, name, apikey, url) FROM '$$PATH$$/2819.dat';

--
-- Name: approval approval_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.approval
    ADD CONSTRAINT approval_pkey PRIMARY KEY (id);


--
-- Name: servicerule servicerule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.servicerule
    ADD CONSTRAINT servicerule_pkey PRIMARY KEY (id);


--
-- Name: fki_ServiceRuleFK; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "fki_ServiceRuleFK" ON public.approval USING btree (service_rule);


--
-- Name: approval auto_field_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER auto_field_updated_at BEFORE UPDATE ON public.approval FOR EACH ROW EXECUTE PROCEDURE public.auto_updated_at_column();


--
-- Name: approval ServiceRuleFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.approval
    ADD CONSTRAINT "ServiceRuleFK" FOREIGN KEY (service_rule) REFERENCES public.servicerule(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

